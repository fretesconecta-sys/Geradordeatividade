# 🌸 Gerador de Atividades Adaptadas

Aplicativo web gratuito para professores de educação especial gerarem atividades adaptadas para crianças com **TDAH**, **Déficit Intelectual** e **Necessidades Especiais**, usando Inteligência Artificial.

---

## 🚀 Como colocar no ar (100% gratuito)

### Passo 1 — Pegar a chave gratuita do Google Gemini

1. Acesse **https://aistudio.google.com/apikey**
2. Faça login com sua conta Google
3. Clique em **"Create API key"**
4. Copie a chave gerada (começa com `AIza...`)

> ✅ Gratuito · Sem cartão de crédito · Sem limite mensal generoso

---

### Passo 2 — Subir o projeto no GitHub

1. Acesse **https://github.com** e crie uma conta (grátis)
2. Clique em **"New repository"**
3. Dê o nome `atividades-adaptadas`
4. Clique em **"Create repository"**
5. Faça upload de todos os arquivos desta pasta:
   - `index.html`
   - `vercel.json`
   - `package.json`
   - `api/generate.js`
6. Clique em **"Commit changes"**

---

### Passo 3 — Fazer deploy no Vercel

1. Acesse **https://vercel.com** e crie uma conta com o GitHub (grátis)
2. Clique em **"Add New Project"**
3. Selecione o repositório `atividades-adaptadas`
4. Clique em **"Deploy"**
5. Aguarde o deploy terminar

---

### Passo 4 — Adicionar a chave da API

1. No painel do Vercel, vá em **Settings → Environment Variables**
2. Adicione:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** sua chave `AIza...`
3. Clique em **Save**
4. Vá em **Deployments** → clique no último deploy → **Redeploy**

✅ **Pronto!** O Vercel vai gerar um link do tipo `https://atividades-adaptadas.vercel.app`

---

## 🎯 Como usar o aplicativo

1. Faça upload da **logo da escola** (opcional)
2. Preencha o **nome da escola**, **professor(a)**, **aluno(a)** e **turma**
3. Digite o **tema** da atividade (ex: "Animais da Fazenda")
4. Selecione a **disciplina**
5. Clique em **✨ Gerar Atividade**
6. Clique em **📥 Baixar PDF** → aparece nova janela
7. Clique em **🖨️ Imprimir / Salvar PDF**
8. No diálogo de impressão, escolha **"Salvar como PDF"**

---

## 🛠️ Estrutura do projeto

```
atividades-adaptadas/
├── index.html        → Frontend completo (design rosa)
├── api/
│   └── generate.js   → Função serverless (chama o Gemini)
├── vercel.json       → Configuração do Vercel
├── package.json      → Configuração Node.js
└── README.md         → Este arquivo
```

---

## ❓ Dúvidas frequentes

**A IA não gera atividades?**
→ Verifique se a variável `GEMINI_API_KEY` está correta no Vercel e faça um novo deploy.

**O PDF não abre?**
→ Verifique se o navegador não está bloqueando pop-ups. Libere o site nas configurações.

**Posso personalizar as cores?**
→ Sim! Edite as variáveis CSS no topo do `index.html`.

---

Feito com 💕 para professoras especiais que fazem a diferença todos os dias.

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método não permitido' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Chave da API não configurada no servidor. Adicione GEMINI_API_KEY nas variáveis de ambiente do Vercel.' });
  }

  const { theme, discipline } = req.body;
  if (!theme || !discipline) {
    return res.status(400).json({ error: 'Tema e disciplina são obrigatórios.' });
  }

  const prompt = `Você é especialista em educação especial inclusiva. Crie uma atividade pedagógica ADAPTADA para uma criança com TDAH, Déficit Intelectual e Dificuldade de Atenção.
Tema: "${theme}" | Disciplina: ${discipline}
Regras: linguagem muito simples e acolhedora, máximo 3 tarefas curtas (até 2 frases cada), dica visual/concreta por tarefa.
Responda APENAS com JSON puro (sem markdown, sem texto fora do JSON):
{"titulo":"título curto e divertido","instrucoes":"orientação geral em 2 frases simples","tarefas":[{"texto":"tarefa 1","dica":"dica 1"},{"texto":"tarefa 2","dica":"dica 2"},{"texto":"tarefa 3","dica":"dica 3"}],"encorajamento":"mensagem carinhosa de 1 frase para a criança"}`;

  try {
    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.8, maxOutputTokens: 800 }
        })
      }
    );

    if (!geminiRes.ok) {
      const errData = await geminiRes.json().catch(() => ({}));
      const msg = errData?.error?.message || `Erro Gemini: ${geminiRes.status}`;
      return res.status(geminiRes.status).json({ error: msg });
    }

    const data = await geminiRes.json();
    const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const clean = raw.replace(/```json|```/g, '').trim();
    const activity = JSON.parse(clean);

    return res.status(200).json({ activity });
  } catch (err) {
    console.error('Erro ao gerar atividade:', err);
    return res.status(500).json({ error: 'Erro interno ao gerar a atividade. Tente novamente.' });
  }
}
